<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	<style type="text/css">
		body{
			background-color: white;
		}
		h2{
			color: #810052;
		}
		.btn-color{
  			background-color: #810052;
  			color: #e5ccdc;
		}
		.profile-image-pic{
  			height: 180px;
  			width: 180px;
  			object-fit: cover;
		}
		.cardbody-color{
  			background-color: #e7e8e8;
		}
		a{
  			text-decoration: none;
		}
		a, a:hover {
			color: #000;
			text-decoration: none;
			padding: 5px;
		}
		.socialbtnsbtnsbtns li {
		    list-style: none outside none;
		    display: inline-block;
		}
		.socialbtns li {
		    list-style: none outside none;
		    display: inline-block;
		}
		.socialbtns .fa {
			color: #639fd4;
			text-shadow: 1px 1px 0px #000,
					1px -1px 0px #000,
					-1px 1px 0px #000,
					-1px -1px 0px #000;
			-webkit-text-shadow: 1px 1px 0px #000,
					1px -1px 0px #000,
					-1px 1px 0px #000,
					-1px -1px 0px #000;
			-moz-text-shadow: 1px 1px 0px #000,
					1px -1px 0px #000,
					-1px 1px 0px #000,
					-1px -1px 0px #000;
			-o-text-shadow: 1px 1px 0px #000,
					1px -1px 0px #000,
					-1px 1px 0px #000,
					-1px -1px 0px #000;
			transition: all ease-out 0.5s;
			-moz-transition: all ease-out 0.5s;
			-webkit-transition: all ease-out 0.5s;
			-o-transition: all ease-out 0.5s;
		}
		.socialbtns .fa:hover {
			color: #639fd4;
			text-shadow: 1px 1px 0px #fff,
					1px -1px 0px #fff,
					-1px 1px 0px #fff,
					-1px -1px 0px #fff;
			-webkit-text-shadow: 1px 1px 0px #fff,
					1px -1px 0px #fff,
					-1px 1px 0px #fff,
					-1px -1px 0px #fff;
			-moz-text-shadow: 1px 1px 0px #fff,
					1px -1px 0px #fff,
					-1px 1px 0px #fff,
					-1px -1px 0px #fff;
			-o-text-shadow: 1px 1px 0px #fff,
					1px -1px 0px #fff,
					-1px 1px 0px #fff,
					-1px -1px 0px #fff;
			transition: all ease 0.5s;
			-moz-transition: all ease-in 0.5s;
			-webkit-transition: all ease-in 0.5s;
			-o-transition: all ease-in 0.5s;
		}
	</style>
</head>
<body>
	<div class="container">
    	<div class="row">
      		<div class="col-md-6 offset-md-3">
        		<div class="card my-5">
          			<form class="card-body cardbody-color p-lg-5" method="post" action="user/">
          				<h2 class="text-center">Login Form</h2>
            			<div class="text-center">
              				<img src="https://www.phptpoint.com/images/projects/1569321064.jpg" class="img-fluid profile-image-pic img-thumbnail rounded-circle my-3">
            			</div>
            			<div class="mb-3">
              				<input type="text" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Email" name="email">
            			</div>
            			<div class="mb-3">
              				<input type="password" class="form-control" id="password" placeholder="Password" name="password">
            			</div>
            			<div class="text-center">
            				<button type="submit" class="btn btn-color px-5 mb-5 w-100" name="checkuser">Login</button>
            			</div>
            			<div align="center" class="socialbtns">
							<ul>
								<li><a href="#" class="fa fa-lg fa-facebook"></a></li>
								<li><a href="#" class="fa fa-lg fa-twitter"></a></li>
								<li><a href="#" class="fa fa-lg fa-linkedin"></a></li>
								<li><a href="#" class="fa fa-lg fa-instagram"></a></li>
								<li><a href="#" class="fa fa-lg fa-youtube"></a></li>
							</ul>
						</div>
          			</form>
        		</div>
      		</div>
    	</div>
  	</div>
</body>
</html>