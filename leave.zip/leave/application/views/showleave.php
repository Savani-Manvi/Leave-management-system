<div class="container-fluid h-100">
    <div class="row h-100">
        <div class="col-2" id="green">
            <ul class="navbar-nav ml-auto">
		        <li class="nav-item active"><a href="<?php echo base_url('User/studentdase/') ?>" class="nav-link">Home</a></li>
		        <li class="nav-item active"><a href="<?php echo base_url('User/showleave/') ?>" class="nav-link">List Of Leave</a></li>
				<li class="nav-item"><a href="#" class="nav-link">About</a></li>
		        <li class="nav-item"><a href="#" class="nav-link">Services</a></li>
		    </ul>
        </div>
<?php $var = $this->session->userdata; ?>
		<div class="col-10" style="margin-top: 50px;">
			<div class="col-10" style="margin-top: 70px; margin-bottom: 70px;">
                <h3>List Of Leave</h3>
                <table cellpadding="5" cellpadding="5">
                    <tr style="background: #810052; color: #e5ccdc">
                        <td width="300px" align="center"><b>From Date</b></td>
                        <td width="300px" align="center"><b>To Date</b></td>
                        <td width="200px" align="center"><b>Total Days</b></td>
                        <td width="200px" align="center"><b>Status</b></td>
                    </tr>
<?php
    foreach($data as $row) {
    	$fromdate = implode("/", array_reverse(explode('-', $row->fromdate)));
    	$todate = implode("/", array_reverse(explode('-', $row->todate)));
?>
                    <tr style="border-bottom:1pt solid #e7e8e8;">
                        <td align="center"><?php echo $fromdate; ?> </td>
                        <td align="center"><?php echo $todate; ?> </td>
                        <td align="center"><?php echo $row->days; ?> </td>
                        <td align="center"><?php echo $row->status; ?> </td>
                    </tr>
<?php
    }
?>
                </table>
                <br>           
            </div>               
		</div>
	</div>
</div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
