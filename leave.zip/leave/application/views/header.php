<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	<style type="text/css">
		h2{
			color: #810052;
		}
		.btn-color{
  			background-color: #810052;
  			color: #e5ccdc;
		}
		.cardbody-color{
  			background-color: #e7e8e8;
  			width: 400px;
  			height: 350px;
		}
		a{
  			text-decoration: none;
		}
		a, a:hover {
			color: #000;
			text-decoration: none;
			padding: 5px;
		}
		body{
			background-color: white;
		}
		span{
			color: #810052;
			font-size: 20px;
		}
		button {
			background-color: #810052;
			color: #e5ccdc;
		}
		#green {
            background: #e7e8e8;
            text-align: left;
            color: #810052;
            border-right: 3px solid #810052;
            padding-left: 20px;
   			padding-bottom: 5px;
        }
        a{
			color: #810052;
			font-size: 17px;
		}
		table tr td a{
			font-size: 15px;
			color: #e5ccdc;
		}
		footer{
  			background-color: #e7e8e8;
  			border-top: 3px solid #810052;
  		}
   		h3{
      		margin-bottom: 30px;
      		color: #810052;
    	}
  		.contact-link{
		    display:inline-block;
		    color: #810052;
  		}
        a:hover{
            color: #810052;
        }
		.socialbtns li {
		    list-style: none outside none;
		    display: inline-block;
		    padding: 5px;
		}
		.socialbtns .fa {
			color: #639fd4;
			text-shadow: 1px 1px 0px #000,
					1px -1px 0px #000,
					-1px 1px 0px #000,
					-1px -1px 0px #000;
			-webkit-text-shadow: 1px 1px 0px #000,
					1px -1px 0px #000,
					-1px 1px 0px #000,
					-1px -1px 0px #000;
			-moz-text-shadow: 1px 1px 0px #000,
					1px -1px 0px #000,
					-1px 1px 0px #000,
					-1px -1px 0px #000;
			-o-text-shadow: 1px 1px 0px #000,
					1px -1px 0px #000,
					-1px 1px 0px #000,
					-1px -1px 0px #000;
			transition: all ease-out 0.5s;
			-moz-transition: all ease-out 0.5s;
			-webkit-transition: all ease-out 0.5s;
			-o-transition: all ease-out 0.5s;
		}
		.socialbtns .fa:hover {
			color: #639fd4;
			text-shadow: 1px 1px 0px #fff,
					1px -1px 0px #fff,
					-1px 1px 0px #fff,
					-1px -1px 0px #fff;
			-webkit-text-shadow: 1px 1px 0px #fff,
					1px -1px 0px #fff,
					-1px 1px 0px #fff,
					-1px -1px 0px #fff;
			-moz-text-shadow: 1px 1px 0px #fff,
					1px -1px 0px #fff,
					-1px 1px 0px #fff,
					-1px -1px 0px #fff;
			-o-text-shadow: 1px 1px 0px #fff,
					1px -1px 0px #fff,
					-1px 1px 0px #fff,
					-1px -1px 0px #fff;
			transition: all ease 0.5s;
			-moz-transition: all ease-in 0.5s;
			-webkit-transition: all ease-in 0.5s;
			-o-transition: all ease-in 0.5s;
		}
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg py-3" style="background-color: #e7e8e8; height: 100px; border-bottom: 3px solid #810052;">
  		<div class="container">
    		<a href="#" class="navbar-brand">
      			<img src="https://www.phptpoint.com/images/projects/1569321064.jpg" width="80" alt="" class="d-inline-block align-middle rounded-circle mr-2">
      			<span class="text-uppercase font-weight-bold">Leave Management System</span>
    		</a>
    		<div id="navbarSupportedContent" class="collapse navbar-collapse">
    			<form method="post" action="<?php echo base_url('User/logout/') ?>" class="navbar-nav ml-auto">
					<button class="btn" name="logout">logout</button>
				</form>
    		</div>
  		</div>
	</nav>
	