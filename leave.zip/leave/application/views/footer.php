<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-sm-3">
        <div class="footer-widget">
          <span class="text-uppercase font-weight-bold">Stay In Touch</span>
          <div class="footer-widget-content">
            <a href="#" class="contact-link">leave@gmail.com</a>
            <a href="#" class="contact-link">support@gmail.com </a>
            <a href="#" class="contact-link">1234-567-890</a>
          </div>
          <div class="socialbtns">
            <ul>
              <li><a href="#" class="fa fa-lg fa-facebook"></a></li>
              <li><a href="#" class="fa fa-lg fa-twitter"></a></li>
              <li><a href="#" class="fa fa-lg fa-linkedin"></a></li>
              <li><a href="#" class="fa fa-lg fa-instagram"></a></li>
              <li><a href="#" class="fa fa-lg fa-youtube"></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>
</body>
</html>