<div id="content">
    <div class="container-fluid h-100">
        <div class="row h-100">
            <div class="col-2" id="green">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active"><a href="<?php echo base_url('User/hoddase/') ?>" class="nav-link">Home</a></li>
                    <li><a href="<?php echo base_url('User/showteacher1/') ?>" class="nav-link">Show Teacher</a></li>
                    <li><a href="<?php echo base_url('User/showstudent1/') ?>" class="nav-link">Show Student</a></li>
                    <li><a href="<?php echo base_url('User/showhodleave/') ?>" class="nav-link">List Of Leave Application</a></li>
                    <li class="nav-item"><a href="#" class="nav-link">About</a></li>
                    <li class="nav-item"><a href="#" class="nav-link">Services</a></li>
                </ul>
            </div>
            <div class="col-10" style="margin-top: 70px; margin-bottom: 70px;">
                <h3>All Student</h3>
                <table cellpadding="5" cellpadding="5">
                    <tr style="background: #810052; color: #e5ccdc">
                        <td width="200px" align="center"><b>Name</b></td>
                        <td width="200px" align="center"><b>Field</b></td>
                        <td width="300px" align="center"><b>Email</b></td>
                        <td width="200px" align="center"><b>Password</b></td>
                        <td width="450px" align="center"><b>Edit</b></td>
                        <td width="150px" align="center"><b>Delete</b></td>
                    </tr>
<?php
    foreach($data as $row) {
?>
                    <tr style="border-bottom:1pt solid #e7e8e8;">
                        <td align="center"><?php echo $row->name; ?> </td>
                        <td align="center"><?php echo $row->field; ?> </td>
                        <td align="center"><?php echo $row->email; ?> </td>
                        <td align="center"><?php echo $row->password; ?> </td>
                        <td align="center" class="update">
                            <button class="btn updt_btn" row_id="<?php echo $row->id;?>">Update</button>
                            <div class="studentform" id="studentform_<?php echo $row->id;?>" style="display: none;">
                                <form class="card-body cardbody-color p-lg-5" method="post" action="<?php echo base_url('User/updatestudent1/') ?>">
                                    <div class="mb-3">
                                        <input type="text" class="form-control" id="name" aria-describedby="emailHelp" placeholder="Name" name="name" value="<?php echo $row->name; ?>">
                                    </div>
                                    <div class="mb-3">
                                        <select class="form-control" id="field" aria-describedby="emailHelp" name="field">
                                            <option value="nofield" <?php if($row->field == 'nofield'){echo 'selected';} ?>>
                                                Please Select Field</option>
                                            <option value="Civil" <?php if($row->field == 'Civil'){echo 'selected';} ?>>
                                                Civil</option>
                                            <option value="Computer" <?php if($row->field == 'Computer'){echo 'selected';} ?>>
                                                Computer</option>
                                            <option value="EC" <?php if($row->field == 'EC'){echo 'selected';} ?>>
                                                EC</option>
                                            <option value="Electrical" <?php if($row->field == 'Electrical'){echo 'selected';} ?>>
                                                Electrical</option>
                                            <option value="Mechanical" <?php if($row->field == 'Mechanical'){echo 'selected';} ?>>
                                                Mechanical</option>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" id="email" aria-describedby="emailHelp" name="email" value="<?php echo $row->email; ?>">
                                    </div>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" id="password" name="password" value="<?php echo $row->password; ?>">
                                    </div>
                                    <div class="mb-3" style="display: none;">
                                        <input type="text" class="form-control" id="role" name="role" value="3">
                                    </div>
                                    <div class="mb-3" style="display: none;">
                                        <input type="text" class="form-control" id="id" name="id" value="<?php echo $row->id;?>">
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-color px-5 mb-5 w-100" name="updatestudent">Update Student</button>
                                    </div>
                                </form>
                            </div>
                        </td>
                        <td align="center"><button class="btn delete_btn" id="<?php echo $row->id;?>">Delete</button></td>
                    </tr>
<?php
    }
?>
                </table>
                <br>           
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $(document).on("click", ".updt_btn", function() {
            var row_id = $(this).attr('row_id');
            $('#studentform_'+row_id).toggle();
        });
        $(document).on('click', '.delete_btn', function(){
            $(this).closest("tr").remove();  
            var id = $(this).attr("id"); 
            $.ajax({  
                url:"<?php echo base_url(); ?>User/deletestudent1/",  
                method:"POST",  
                data:{id:id}, 
            });  
        });
    });
</script>