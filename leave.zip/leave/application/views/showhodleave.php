<div class="container-fluid h-100">
    <div class="row h-100">
        <div class="col-2" id="green">
            <ul class="navbar-nav ml-auto">
		        <li class="nav-item active"><a href="<?php echo base_url('User/hoddase/') ?>" class="nav-link">Home</a></li>
				<li><a href="<?php echo base_url('User/showteacher1/') ?>" class="nav-link">Show Teacher</a></li>
				<li><a href="<?php echo base_url('User/showstudent1/') ?>" class="nav-link">Show Student</a></li>
				<li><a href="<?php echo base_url('User/showhodleave/') ?>" class="nav-link">List Of Leave Application</a></li>
				<li class="nav-item"><a href="#" class="nav-link">About</a></li>
		        <li class="nav-item"><a href="#" class="nav-link">Services</a></li>
		    </ul>
        </div>
		<div class="col-10" style="margin-top: 50px;">
			<div id="row">
	           	<div class="col-md-12 text-left">
                    <button type="submit" class="btn" id="showallleave">Filter</button>
                        <form class="card-body cardbody-color p-lg-5" method="post" action="<?php echo base_url('User/saveuser1/') ?>">
                            <div class="mb-3">
                                <input type="text" class="form-control" id="name" aria-describedby="emailHelp" placeholder="From Date" name="name">
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control" id="name" aria-describedby="emailHelp" placeholder="To Date" name="name">
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-color px-5 mb-5 w-100">Download Excel File</button>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-color px-5 mb-5 w-100">Download CSV File</button>
                            </div>
                        </form>
	           	</div>
           	</div>
			<div class="col-10" style="margin-top: 70px; margin-bottom: 70px;" id="oneweekleave">
                <h3>List of Leave</h3>
                <table cellpadding="5" cellpadding="5">
                    <tr style="background: #810052; color: #e5ccdc">
                    	<td width="200px" align="center"><b>Name</b></td>
                    	<td width="200px" align="center"><b>Field</b></td>
                        <td width="200px" align="center"><b>From Date</b></td>
                        <td width="200px" align="center"><b>To Date</b></td>
                        <td width="150px" align="center"><b>Total Days</b></td>
                        <td width="200px" align="center"><b>Status</b></td>
                        <td width="300px" align="center"><b>Action</b></td>
                    </tr>
<?php
    foreach($data as $row) {
    	$fromdate = implode("/", array_reverse(explode('-', $row->fromdate)));
    	$todate = implode("/", array_reverse(explode('-', $row->todate)));
?>
                    <tr style="border-bottom:1pt solid #e7e8e8;">
                        <td align="center"><?php echo $row->name; ?></td>
                        <td align="center"><?php echo $row->field; ?></td>
                        <td align="center"><?php echo $fromdate; ?> </td>
                        <td align="center"><?php echo $todate; ?> </td>
                        <td align="center"><?php echo $row->days; ?> </td>
                        <td align="center"><?php echo $row->status; ?> </td>
                        <td align="center">
                        	<button class="btn accept_btn" id="<?php echo $row->id;?>" >Accept</button>
                        	<button class="btn reject_btn" id="<?php echo $row->id;?>" >Reject</button>
                        </td>
                    </tr>
<?php
    }
?>
                </table>
                <br>           
            </div>              
		</div>
	</div>
</div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $(document).on('click', '.accept_btn', function(){
            $(this).closest("tr").remove();  
            var id = $(this).attr("id"); 
            $.ajax({  
                url:"<?php echo base_url(); ?>User/acceptleave/",  
                method:"POST",  
                data:{id:id}, 
            });  
        });
        $(document).on('click', '.reject_btn', function(){
            $(this).closest("tr").remove();  
            var id = $(this).attr("id"); 
            $.ajax({  
                url:"<?php echo base_url(); ?>User/rejectleave/",  
                method:"POST",  
                data:{id:id}, 
            });  
        });
    });
</script>