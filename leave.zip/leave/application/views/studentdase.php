<div class="container-fluid h-100">
    <div class="row h-100">
        <div class="col-2" id="green">
            <ul class="navbar-nav ml-auto">
		        <li class="nav-item active"><a href="<?php echo base_url('User/studentdase/') ?>" class="nav-link">Home</a></li>
		        <li class="nav-item active"><a href="<?php echo base_url('User/showleave/') ?>" class="nav-link">List Of Leave</a></li>
				<li class="nav-item"><a href="#" class="nav-link">About</a></li>
		        <li class="nav-item"><a href="#" class="nav-link">Services</a></li>
		    </ul>
        </div>
<?php $var = $this->session->user;
$field = $var[0]->field;
?>
		<div class="col-10" style="margin-top: 50px;">
			 <ul style="list-style: none outside none; margin-bottom: 70px;">
				<br>
				<li style="margin-bottom: 40px;">
					<button onclick="myLeave()" class="btn" name="student">Add Leave</button>
					<div id="leaveform" style="display: none;">
				      	<form class="card-body cardbody-color p-lg-5" method="post" action="<?php echo base_url('User/applyleave/') ?>">
				      		<div class="mb-3" style="display: none">
		           				<input type="text" class="form-control" id="name" aria-describedby="emailHelp" placeholder="Name" name="name" value="<?php echo $var[0]->name; ?>">
		           			</div>
		           			<div class="mb-3" style="display: none">
		           				<select class="form-control" id="field" aria-describedby="emailHelp" name="field">
		           					<option value="nofield" <?php if($field == 'nofield'){echo 'selected';} ?>>
		           						Please Select Field</option>
		           					<option value="Civil" <?php if($field == 'Civil'){echo 'selected';} ?>>
		           						Civil</option>
		           					<option value="Computer" <?php if($field == 'Computer'){echo 'selected';} ?>>
		           						Computer</option>
		           					<option value="EC" <?php if($field == 'EC'){echo 'selected';} ?>>
		           						EC</option>
		           					<option value="Electrical" <?php if($field == 'Electrical'){echo 'selected';} ?>>
		           						Electrical</option>
		           					<option value="Mechanical" <?php if($field == 'Mechanical'){echo 'selected';} ?>>
		           						Mechanical</option>
		           				</select>
		           			</div>
			           		<div class="mb-3" style="display: none">
			           			<input type="text" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Email" name="email" value="<?php echo $var[0]->email; ?>">
			           		</div>
			       			<div class="mb-3">
			     				<input type="date" class="form-control" id="fromdate" name="fromdate">
			            	</div>
			            	<div class="mb-3">
			         			<input type="date" class="form-control" id="todate" name="todate">
			           		</div>
			           		<div class="mb-3" style="display: none">
			           			<input type="text" class="form-control" id="status" aria-describedby="emailHelp" placeholder="Status" name="status" value="Pending">
			           		</div>
			           		<div class="text-center">
			           			<button type="submit" class="btn btn-color px-5 mb-5 w-100">Apply For Leave</button>
			          		</div>
			          	</form>
			    	</div>
				</li>
			</ul>               
		</div>
	</div>
</div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
    function myLeave() {
        var x = document.getElementById('leaveform');
        if (x.style.display === 'none') {
            x.style.display = 'block';
        } else {
            x.style.display = 'none';
        }
    }
    $(function(){
	    var dtToday = new Date();
	    var month = dtToday.getMonth() + 1;
	    var day = dtToday.getDate();
	    var year = dtToday.getFullYear();
	    if(month < 10)
	        month = '0' + month.toString();
	    if(day < 10)
	     day = '0' + day.toString();
	    var maxDate = year + '-' + month + '-' + day;
	    $('#fromdate').attr('min', maxDate);
	});
	$(document).ready(function(){
		$("#fromdate").on("change", function(){
	  		$("#todate").attr("min", $(this).val());
		});
	});
	
</script>