<div class="container-fluid h-100">
    <div class="row h-100">
        <div class="col-2" id="green">
            <ul class="navbar-nav ml-auto">
		        <li class="nav-item active"><a href="<?php echo base_url('User/teacherdase/') ?>" class="nav-link">Home</a></li>
				<li><a href="<?php echo base_url('User/showstudent2/') ?>" class="nav-link">Show Student</a></li>
				<li class="nav-item"><a href="#" class="nav-link">About</a></li>
		        <li class="nav-item"><a href="#" class="nav-link">Services</a></li>
		    </ul>
        </div>
		<div class="col-10" style="margin-top: 50px;">
			<ul style="list-style: none outside none; margin-bottom: 70px;">
				<br>
				<li style="margin-bottom: 40px;">
					<button onclick="myStudent()" class="btn" name="student">Add Student</button>
					<div id="studentform" style="display: none;">
				      	<form class="card-body cardbody-color p-lg-5" method="post" action="<?php echo base_url('User/saveuser2/') ?>">
				      		<div class="mb-3">
		           				<input type="text" class="form-control" id="name" aria-describedby="emailHelp" placeholder="Name" name="name">
		           			</div>
		           			<div class="mb-3">
		           				<select class="form-control" id="field" aria-describedby="emailHelp" name="field">
		           					<option value="nofield">Please Select Field</option>
		           					<option value="Civil">Civil</option>
		           					<option value="Computer">Computer</option>
		           					<option value="EC">EC</option>
		           					<option value="Electrical">Electrical</option>
		           					<option value="Mechanical">Mechanical</option>
		           				</select>
		           			</div>
			           		<div class="mb-3">
			           			<input type="text" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Email" name="email">
			           		</div>
			       			<div class="mb-3">
			     				<input type="password" class="form-control" id="password" placeholder="Password" name="password">
			            	</div>
			            	<div class="mb-3" style="display: none;">
			         			<input type="text" class="form-control" id="role" placeholder="role" name="role" value="4">
			           		</div>
			           		<div class="text-center">
			           			<button type="submit" class="btn btn-color px-5 mb-5 w-100">Save Student</button>
			          		</div>
			          	</form>
			    	</div>
				</li>
			</ul>               
		</div>
	</div>
</div>
<script>
    function myStudent() {
        var x = document.getElementById('studentform');
        if (x.style.display === 'none') {
            x.style.display = 'block';
        } else {
            x.style.display = 'none';
        }
    }
</script>