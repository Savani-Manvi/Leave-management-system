<?php

	class User extends CI_Controller {
		
		function __construct() {
			parent::__construct();
			$this->load->database();
			$this->load->library('session');
			$this->load->library('form_validation');
			$this->load->model('User_model');
			$this->load->helper('file');
			error_reporting(E_ERROR | E_PARSE);
		}

		public function index() {
			$this->load->view('login');
		}

		public function import(){
	        $data = array();
	        $memData = array();
	        if($this->input->post('importSubmit')){
	            $this->form_validation->set_rules('file', 'CSV file', 'callback_file_check');
	            if($this->form_validation->run() == true){
	                $insertCount = $updateCount = $rowCount = $notAddCount = 0;
	                if(is_uploaded_file($_FILES['file']['tmp_name'])){
	                    $this->load->library('CSVReader');
	                    $csvData = $this->csvreader->parse_csv($_FILES['file']['tmp_name']);
	                    if(!empty($csvData)){
	                        foreach($csvData as $row){ 
	                            $rowCount++;
	                            $memData = array(
	                            	'name' => $row['Name'],
	                            	'field' => $row['Field'],
	                                'email' => $row['Email'],
	                                'password' => $row['Password'],
	                                'role' => $row['Role'],
	                            );
	                            $con = array(
	                                'where' => array(
	                                    'email' => $row['Email']
	                                ),
	                                'returnType' => 'count'
	                            );
	                            $prevCount = $this->User_model->getRows($con);
	                            if($prevCount > 0){
	                                $condition = array('email' => $row['Email']);
	                                $update = $this->User_model->update($memData, $condition);
	                                if($update){
	                                    $updateCount++;
	                                }
	                            }
	                            else{
	                                $insert = $this->User_model->insert($memData);
	                                if($insert){
	                                    $insertCount++;
	                                }
	                            }
	                        }
	                    }
	                }else{
	                    $this->session->set_userdata('error_msg', 'Error on file upload, please try again.');
	                }
	            }else{
	                $this->session->set_userdata('error_msg', 'Invalid file, please select only CSV file.');
	            }
	        }
	        $this->load->view('header');
			$this->load->view('admindase');
			$this->load->view('footer');
	    }

	    public function file_check($str){
	        $allowed_mime_types = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
	        if(isset($_FILES['file']['name']) && $_FILES['file']['name'] != ""){
	            $mime = get_mime_by_extension($_FILES['file']['name']);
	            $fileAr = explode('.', $_FILES['file']['name']);
	            $ext = end($fileAr);
	            if(($ext == 'csv') && in_array($mime, $allowed_mime_types)){
	                return true;
	            }else{
	                $this->form_validation->set_message('file_check', 'Please select only CSV file to upload.');
	                return false;
	            }
	        }else{
	            $this->form_validation->set_message('file_check', 'Please select a CSV file to upload.');
	            return false;
	        }
	    }

	    public function user() {  
		    $email = $this->input->post('email');  
		    $password = $this->input->post('password');  
		    $data = array('email'=>$email, 'password'=>$password);
	        $user = $this->User_model->user($data);
	        $this->session->set_userdata('user', $user);
	        if (isset($user) && !empty($user)) {
		       	if($user[0]->role == 1) {
			       	$this->load->view('header');
			       	$this->load->view('admindase');
			       	$this->load->view('footer');
			   	}
		    	elseif($user[0]->role == 2) {
		    		$this->load->view('header');
		       		$this->load->view('hoddase');
		       		$this->load->view('footer');	
		       	}
			    elseif($user[0]->role == 3) {
			    	$this->load->view('header');
			   		$this->load->view('teacherdase');
			   		$this->load->view('footer');		
		       	}
		       	elseif($user[0]->role == 4) {
			    	$this->load->view('header');
			   		$this->load->view('studentdase');
			   		$this->load->view('footer');		
		       	}
		    }
		    else{
		    	$this->load->view('error');
		    }
		}

		public function admindase() {
			$this->load->view('header');
			$this->load->view('admindase');
			$this->load->view('footer');
		}

		public function saveuser() {
			$name = $this->input->post('name');
			$field = $this->input->post('field');
    		$email = $this->input->post('email');  
		    $password = $this->input->post('password');
		    $role = $this->input->post('role');
		    $data = array('name'=>$name, 'field'=>$field, 'email'=>$email, 'password'=>$password, 'role'=>$role);
		    $check = $this->User_model->check($email);
			if (empty($check)) {
				$this->User_model->saveuser($data);
			   	$this->load->view('header');
		       	$this->load->view('admindase');
		       	$this->load->view('footer');
		   	}
		    else{
		    	$this->load->view('header');
		       	$this->load->view('admindaseerror');
		       	$this->load->view('footer');
		    }
    	}

    	public function showhod() {
			$this->load->view('header');
			$result['data']=$this->User_model->showhod();
			$this->load->view('showhod',$result);
			$this->load->view('footer');	
		}

		public function showteacher() {
			$this->load->view('header');
			$result['data']=$this->User_model->showteacher();
			$this->load->view('showteacher',$result);
			$this->load->view('footer');	
		}

		public function showstudent() {
			$this->load->view('header');
			$result['data']=$this->User_model->showstudent();
			$this->load->view('showstudent',$result);
			$this->load->view('footer');	
		}

		public function updatehod() {
    		$id = $this->input->post('id');
    		$name = $this->input->post('name');
    		$field = $this->input->post('field');
    		$email = $this->input->post('email');  
		    $password = $this->input->post('password');
		    $data = array('name'=>$name, 'field'=>$field, 'email'=>$email, 'password'=>$password);
		    $result['data'] = $this->User_model->updatehod($data, $id);
		    $this->load->view('header');
			$this->load->view('showhod',$result);
			$this->load->view('footer');
    	}

    	public function updateteacher() {
    		$id = $this->input->post('id');
    		$name = $this->input->post('name');
    		$field = $this->input->post('field');
    		$email = $this->input->post('email');  
		    $password = $this->input->post('password');
		    $data = array('name'=>$name, 'field'=>$field, 'email'=>$email, 'password'=>$password);
		    $result['data'] = $this->User_model->updateteacher($data, $id);
		    $this->load->view('header');
			$this->load->view('showteacher',$result);
			$this->load->view('footer');
    	}

    	public function updatestudent() {
    		$id = $this->input->post('id');
    		$name = $this->input->post('name');
    		$field = $this->input->post('field');
    		$email = $this->input->post('email');  
		    $password = $this->input->post('password');
		    $data = array('name'=>$name, 'field'=>$field, 'email'=>$email, 'password'=>$password);
		    $result['data'] = $this->User_model->updatestudent($data, $id);
		    $this->load->view('header');
			$this->load->view('showstudent',$result);
			$this->load->view('footer');
    	}

    	public function deletehod() {    
            $result['data']=$this->User_model->deletehod($_POST["id"]);  
            $this->load->view('header');
			$this->load->view('showhod',$result);
			$this->load->view('footer');
      	}

      	public function deleteteacher() {    
            $result['data']=$this->User_model->deleteteacher($_POST["id"]);  
            $this->load->view('header');
			$this->load->view('showteacher',$result);
			$this->load->view('footer');
      	}

		public function deletestudent() {    
            $result['data']=$this->User_model->deletestudent($_POST["id"]);  
            $this->load->view('header');
			$this->load->view('showstudent',$result);
			$this->load->view('footer');
      	}

      	public function hoddase() {
			$this->load->view('header');
			$this->load->view('hoddase');
			$this->load->view('footer');
		}

    	public function saveuser1() {
    		$name = $this->input->post('name');
			$field = $this->input->post('field');
    		$email = $this->input->post('email');  
		    $password = $this->input->post('password');
		    $role = $this->input->post('role');
		    $data = array('name'=>$name, 'field'=>$field, 'email'=>$email, 'password'=>$password, 'role'=>$role);
		    $check = $this->User_model->check($email);
		    if (empty($check)) {
		       	$this->User_model->saveuser($data);
			   	$this->load->view('header');
				$this->load->view('hoddase');
				$this->load->view('footer');
		   	}
		    else {
		    	$this->load->view('header');
		       	$this->load->view('hoddaseerror');
		   		$this->load->view('footer');	
	    	}
    	}

      	public function showteacher1() {
			$this->load->view('header');
			$result['data']=$this->User_model->showteacher();
			$this->load->view('showteacher1',$result);
			$this->load->view('footer');	
		}

		public function showstudent1() {
			$this->load->view('header');
			$result['data']=$this->User_model->showstudent();
			$this->load->view('showstudent1',$result);
			$this->load->view('footer');	
		} 

		public function showhodleave() {
			$result['data']=$this->User_model->showallhodleave();
			$this->load->view('header');
			$this->load->view('showhodleave',$result);
			$this->load->view('footer');
		}  

    	public function acceptleave() {    
            $result['data'] = $this->User_model->acceptleave($_POST["id"]);  
            $this->load->view('header');
			$this->load->view('showhodleave',$result);
			$this->load->view('footer');
      	}

      	public function rejectleave() {    
            $result['data'] = $this->User_model->rejectleave($_POST["id"]);  
            $this->load->view('header');
			$this->load->view('showhodleave',$result);
			$this->load->view('footer');
      	}

		public function updateteacher1() {
    		$id = $this->input->post('id');
    		$name = $this->input->post('name');
    		$field = $this->input->post('field');
    		$email = $this->input->post('email');  
		    $password = $this->input->post('password');
		    $data = array('name'=>$name, 'field'=>$field, 'email'=>$email, 'password'=>$password);
		    $result['data'] = $this->User_model->updateteacher($data, $id);
		    $this->load->view('header');
			$this->load->view('showteacher1',$result);
			$this->load->view('footer');
    	}

    	public function updatestudent1() {
    		$id = $this->input->post('id');
    		$name = $this->input->post('name');
    		$field = $this->input->post('field');
    		$email = $this->input->post('email');  
		    $password = $this->input->post('password');
		    $data = array('name'=>$name, 'field'=>$field, 'email'=>$email, 'password'=>$password);
		    $result['data'] = $this->User_model->updatestudent($data, $id);
		    $this->load->view('header');
			$this->load->view('showstudent1',$result);
			$this->load->view('footer');
    	} 

    	public function deleteteacher1() {    
            $result['data']=$this->User_model->deleteteacher($_POST["id"]);  
            $this->load->view('header');
			$this->load->view('showteacher1',$result);
			$this->load->view('footer');
      	}

		public function deletestudent1() {    
            $result['data']=$this->User_model->deletestudent($_POST["id"]);  
            $this->load->view('header');
			$this->load->view('showstudent1',$result);
			$this->load->view('footer');
      	}  	

      	public function teacherdase() {
			$this->load->view('header');
			$this->load->view('teacherdase');
			$this->load->view('footer');
		}

    	public function saveuser2() {
    		$name = $this->input->post('name');
			$field = $this->input->post('field');
    		$email = $this->input->post('email');  
		    $password = $this->input->post('password');
		    $role = $this->input->post('role');
		    $data = array('name'=>$name, 'field'=>$field, 'email'=>$email, 'password'=>$password, 'role'=>$role);
		    $check = $this->User_model->check($email);
		    if (empty($check)) {
		       	$this->User_model->saveuser($data);
			    $this->load->view('header');
				$this->load->view('teacherdase');
				$this->load->view('footer');
		   	}
	    	else {
		    	$this->load->view('header');
		       	$this->load->view('teacherdaseerror');
		   		$this->load->view('footer');	
	    	}
    	}

		public function showstudent2() {
			$this->load->view('header');
			$result['data']=$this->User_model->showstudent();
			$this->load->view('showstudent2',$result);
			$this->load->view('footer');	
		}

    	public function updatestudent2() {
    		$id = $this->input->post('id');
    		$name = $this->input->post('name');
    		$field = $this->input->post('field');
    		$email = $this->input->post('email');  
		    $password = $this->input->post('password');
		    $data = array('name'=>$name, 'field'=>$field, 'email'=>$email, 'password'=>$password);
		    $result['data'] = $this->User_model->updatestudent($data, $id);
		    $this->load->view('header');
			$this->load->view('showstudent2',$result);
			$this->load->view('footer');
    	} 

		public function deletestudent2() {    
            $result['data']=$this->User_model->deletestudent($_POST["id"]);  
            $this->load->view('header');
			$this->load->view('showstudent2',$result);
			$this->load->view('footer');
      	}

      	public function studentdase() {
			$this->load->view('header');
			$this->load->view('studentdase');
			$this->load->view('footer');
		}

		public function applyleave() {
			$name = $this->input->post('name');
			$field = $this->input->post('field');
    		$email = $this->input->post('email');  
		    $fromdate = $this->input->post('fromdate');
		    $todate = $this->input->post('todate');
		    $diff = abs(strtotime($todate) - strtotime($fromdate));
			$years = floor($diff / (365*60*60*24));
			$months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
			$days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
		    $status = $this->input->post('status');
		    $data = array('name'=>$name, 'field'=>$field, 'email'=>$email, 'fromdate'=>$fromdate, 'todate'=>$todate, 'days'=>$days, 'status'=>$status);
		    $this->User_model->applyleave($data);
			$this->load->view('header');
			$this->load->view('studentdase');
			$this->load->view('footer');
    	}

    	public function showleave() {
    		$email = $this->session->email;
    		$result['data'] = $this->User_model->showleave();
    		$this->load->view('header');
			$this->load->view('showleave', $result);
			$this->load->view('footer');
    	}

    	public function logout() {
    		$this->session->unset_userdata('user');
    		$this->load->view('login');
    	}

	}

?>