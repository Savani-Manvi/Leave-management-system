<?php

	class User_model extends CI_Model {

		function __construct() {
        	$this->table = 'user';
    	}

    	function getRows($params = array()){
	        $this->db->select('*');
	        $this->db->from($this->table);
	        if(array_key_exists("where", $params)){
	            foreach($params['where'] as $key => $val){
	                $this->db->where($key, $val);
	            }
	        }
        	if(array_key_exists("returnType",$params) && $params['returnType'] == 'count'){
            	$result = $this->db->count_all_results();
        	}
        	else{
	            if(array_key_exists("id", $params)){
	                $this->db->where('id', $params['id']);
	                $query = $this->db->get();
	                $result = $query->row_array();
	            }
	            else{
	                $this->db->order_by('id', 'desc');
	                if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
	                    $this->db->limit($params['limit'],$params['start']);
	                }
	                elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
	                    $this->db->limit($params['limit']);
	                }
	                $query = $this->db->get();
	                $result = ($query->num_rows() > 0)?$query->result_array():FALSE;
            	}
        	}
        	return $result;
    	}
    
    	public function insert($data = array()) {
        	if(!empty($data)){
            	$insert = $this->db->insert($this->table, $data);
            	return $insert?$this->db->insert_id():false;
        	}
        	return false;
    	}
    
	    public function update($data, $condition = array()) {
	        if(!empty($data)){
	            $update = $this->db->update($this->table, $data, $condition);
	            return $update?true:false;
	        }
	        return false;
	    } 

		public function user($data) {
			$query = $this->db->select('*')->where($data)->get('user');
			return $query->result();
		}

		public function getbyemail($email) {
			$query = $this->db->select('*')->where('email', $email)->get('user');
			return $query->result();
		}

		public function check($email) {
    		$query = $this->db->where('email',$email)->get('user');
    		return $query->result();
		}

		public function saveuser($data) {
			$query = $this->db->insert('user', $data);
		}

		public function showhod() {
		    $query=$this->db->select('*')->order_by('id','DESC')->where('role', 2)->get('user');
		    return $query->result();
	  	}

	  	public function showteacher() {
		    $query=$this->db->select('*')->order_by('id','DESC')->where('role', 3)->get('user');
		    return $query->result();
	  	}

	  	public function showstudent() {
		    $query=$this->db->select('*')->order_by('id','DESC')->where('role', 4)->get('user');
		    return $query->result();
	  	}

	  	public function showhodleave($date, $date1) {
		    $query=$this->db->select('*')->order_by('id','DESC')->where("date BETWEEN '$date1' AND '$date'")->get('userleave');
		    return $query->result();
	  	}

	  	public function showallhodleave() {
		    $query=$this->db->select('*')->order_by('id','DESC')->get('userleave');
		    return $query->result();
	  	}

	  	public function updatehod($data, $id) {
	  		$query=$this->db->where("id", $id)->update('user', $data);	
	  		$query1=$this->db->select('*')->order_by('id','DESC')->where('role', 2)->get('user');
		    return $query1->result();
	  	}

	  	public function updateteacher($data, $id) {
	  		$query=$this->db->where("id", $id)->update('user', $data);	
	  		$query1=$this->db->select('*')->order_by('id','DESC')->where('role', 3)->get('user');
		    return $query1->result();
	  	}

	  	public function updatestudent($data, $id) {
	  		$query=$this->db->where("id", $id)->update('user', $data);	
	  		$query1=$this->db->select('*')->order_by('id','DESC')->where('role', 4)->get('user');
		    return $query1->result();
	  	}

	  	public function deletehod($id)  {  
            $query=$this->db->where("id", $id)->delete('user'); 
            $query1=$this->db->select('*')->order_by('id','DESC')->where('role', 2)->get('user');
		    return $query1->result();
      	} 

      	public function deleteteacher($id)  {  
            $query=$this->db->where("id", $id)->delete('user'); 
            $query1=$this->db->select('*')->order_by('id','DESC')->where('role', 3)->get('user');
		    return $query1->result();
      	} 

      	public function deletestudent($id)  {  
            $query=$this->db->where("id", $id)->delete('user'); 
            $query1=$this->db->select('*')->order_by('id','DESC')->where('role', 4)->get('user');
		    return $query1->result();
      	}

      	public function applyleave($data) {
			$query = $this->db->insert('userleave', $data);
		}

		public function acceptleave($id)  {  
            $query=$this->db->set('status', "Accept")->where('id', $id)->update('userleave'); 
            $query1=$this->db->select('*')->order_by('id','DESC')->where('email', $email)->get('userleave');
		    return $query1->result();
      	}

      	public function rejectleave($id)  {  
            $query=$this->db->set('status', "Reject")->where('id', $id)->update('userleave'); 
            $query1=$this->db->select('*')->order_by('id','DESC')->where('email', $email)->get('userleave');
		    return $query1->result();
      	}

		public function showleave() {
			$query1=$this->db->select('*')->order_by('id','DESC')->where('email', "ccc@gmail.com")->get('userleave');
		    return $query1->result();
		}

	}

?>